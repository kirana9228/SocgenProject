import React, { Component } from 'react'
import ItemService from '../services/ItemService'

class ListItemComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
                Items: []
        }
        this.addItem = this.addItem.bind(this);
        this.editItem = this.editItem.bind(this);
        this.deleteItem = this.deleteItem.bind(this);
    }

    deleteItem(id){
        ItemService.deleteItem(id).then( res => {
            this.setState({Items: this.state.Items.filter(Item => Item.id !== id)});
        });
    }
    viewItem(id){
        this.props.history.push(`/view-Item/${id}`);
    }
    editItem(id){
        this.props.history.push(`/update-Item/${id}`);
    }

    componentDidMount(){
        ItemService.getItems().then((res) => {
            this.setState({ Items: res.data});
            console.log(res.data)
        });
    
    }

    addItem(){
        this.props.history.push('/add-Item/_add');
    }

    render() {
        return (
            <div>
                 <h2 className="text-center">Items List</h2>
                 <div className = "row">
                    <button className="btn btn-primary" onClick={this.addItem}> Add Item</button>
                 </div>
                 <br></br>
                 <div className = "row">
                        <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th> Item Name</th>
                                    <th> Quantity</th>
                                    <th> Cost</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {
                                    this.state.Items.map(
                                        Item => 
                                        <tr key = {Item.id}>
                                             <td> { Item.itemName} </td>   
                                             <td> {Item.quantity}</td>
                                             <td> {Item.cost}</td>
                                             <td>
                                                 <button onClick={ () => this.editItem(Item.id)} className="btn btn-info">Update </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.deleteItem(Item.id)} className="btn btn-danger">Delete </button>
                                                 <button style={{marginLeft: "10px"}} onClick={ () => this.viewItem(Item.id)} className="btn btn-info">View </button>
                                             </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                        </table>

                 </div>

            </div>
        )
    }
}

export default ListItemComponent
