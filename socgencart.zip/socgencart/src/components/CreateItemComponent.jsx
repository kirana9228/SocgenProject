import React, { Component } from 'react'
import ItemService from '../services/ItemService';

class CreateItemComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            ItemName: '',
            Quantity: '',
            Cost: ''
        }
        this.changeItemNameHandler = this.changeItemNameHandler.bind(this);
        this.changeQuantityHandler = this.changeQuantityHandler.bind(this);
        this.saveOrUpdateItem = this.saveOrUpdateItem.bind(this);
    }

    // step 3
    componentDidMount(){

        // step 4
        if(this.state.id === '_add'){
            return
        }else{
            ItemService.getItemById(this.state.id).then( (res) =>{
                let Item = res.data;
                this.setState({ItemName: Item.ItemName,
                    Quantity: Item.Quantity,
                    Cost : Item.Cost
                });
            });
        }        
    }
    saveOrUpdateItem = (e) => {
        e.preventDefault();
        let Item = {ItemName: this.state.ItemName, Quantity: this.state.Quantity, Cost: this.state.Cost};
        console.log('Item => ' + JSON.stringify(Item));

        // step 5
        if(this.state.id === '_add'){
            ItemService.createItem(Item).then(res =>{
                this.props.history.push('/Items');
            });
        }else{
            ItemService.updateItem(Item, this.state.id).then( res => {
                this.props.history.push('/Items');
            });
        }
    }
    
    changeItemNameHandler= (event) => {
        this.setState({ItemName: event.target.value});
    }

    changeQuantityHandler= (event) => {
        this.setState({Quantity: event.target.value});
    }

    changeEmailHandler= (event) => {
        this.setState({Cost: event.target.value});
    }

    cancel(){
        this.props.history.push('/Items');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Add Item</h3>
        }else{
            return <h3 className="text-center">Update Item</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Item Name: </label>
                                            <input placeholder="Item Name" name="ItemName" className="form-control" 
                                                value={this.state.ItemName} onChange={this.changeItemNameHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Quantity: </label>
                                            <input placeholder="Quantity" name="Quantity" className="form-control" 
                                                value={this.state.Quantity} onChange={this.changeQuantityHandler}/>
                                        </div>
                                        <div className = "form-group">
                                            <label> Cost: </label>
                                            <input placeholder="Cost" name="Cost" className="form-control" 
                                                value={this.state.Cost} onChange={this.changeEmailHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.saveOrUpdateItem}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default CreateItemComponent
