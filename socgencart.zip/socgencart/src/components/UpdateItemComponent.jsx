import React, { Component } from 'react'
import ItemService from '../services/ItemService';

class UpdateItemComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            ItemName: '',
            Quantity: '',
            Cost: ''
        }

        this.changeQuantityHandler = this.changeQuantityHandler.bind(this);
        this.updateItem = this.updateItem.bind(this);
    }

    componentDidMount(){
        ItemService.getItemById(this.state.id).then( (res) =>{
            let Item = res.data;
            this.setState({ItemName: Item.itemName,
                Quantity: Item.quantity,
                Cost : Item.cost
            });
            console.log(this.state.ItemName+"::"+this.state.Cost+"::"+this.state.Quantity);
        });
    }

    updateItem = (e) => {
        e.preventDefault();
        let Item = {ItemName: this.state.ItemName, Quantity: this.state.Quantity, Cost: this.state.Cost};
        console.log('Item => ' + JSON.stringify(Item));
        console.log('id => ' + JSON.stringify(this.state.id));
        ItemService.updateItem(Item, this.state.id).then( res => {
            this.props.history.push('/Items');
        });
    }
    

    changeQuantityHandler= (event) => {
        this.setState({Quantity: event.target.value});
    }

    cancel(){
        this.props.history.push('/Items');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Item</h3>
                                <div className = "card-body">
                                    <form>
                                        
                                        <div className = "form-group">
                                            <label> Quatity: </label>
                                            <input placeholder="Quantity" name="Quantity" className="form-control" 
                                                value={this.state.Quantity} onChange={this.changeQuantityHandler}/>
                                        </div>
                                        

                                        <button className="btn btn-success" onClick={this.updateItem}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                   </div>
            </div>
        )
    }
}

export default UpdateItemComponent
