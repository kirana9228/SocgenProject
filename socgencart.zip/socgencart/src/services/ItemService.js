import axios from 'axios';

const Item_API_BASE_URL = "http://localhost:8080/api/v1/items";

class ItemService {

    getItems(){
        return axios.get(Item_API_BASE_URL);
    }

    createItem(Item){
        return axios.post(Item_API_BASE_URL, Item);
    }

    getItemById(ItemId){
        return axios.get(Item_API_BASE_URL + '/' + ItemId);
    }

    updateItem(Item, ItemId){
        return axios.put(Item_API_BASE_URL + '/' + ItemId, Item);
    }

    deleteItem(ItemId){
        return axios.delete(Item_API_BASE_URL + '/' + ItemId);
    }
}

export default new ItemService()